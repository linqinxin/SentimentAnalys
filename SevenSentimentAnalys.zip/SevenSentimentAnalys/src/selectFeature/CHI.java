/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package selectFeature;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.TreeMap;

import Utils.FilePath;

/**
 * 
 * @author Administrator
 */
public class CHI {

	// ����ÿ���ʺ���������ֵ������ͳ��ֵ��
	static TreeMap<String, Double> feature = new TreeMap<String, Double>();

	// �������е�ѵ��������ÿһƪ΢����һ�������ʽ����
	private static HashMap<Double, TrainSet> allTrain ;
	private static double all ;

	// ���ÿ�����������Ŀ����0��3�ֱ�ΪANGRY, HAPPY,DOWN,DISGUST;
	private static double[] classes ;

	// ѵ������������
	private static BufferedReader readEverySet;
	private static BufferedWriter result;

	//ѵ����·��
	   private  static String[][] trainPath=FilePath.MUL_DIV_RESULT_PATH;
	   
	    private static final void coutCHI( ) throws IOException{
	    	feature=new TreeMap<String,Double>( );   	
	    	allTrain=new HashMap<Double,TrainSet>(); 
	    	all = 0;
	    	classes=new double[]{0.0,0.0,0.0,0.0,0.0,0.0,0.0};
	    	//������ȡ��������
			result = new BufferedWriter(new OutputStreamWriter(
					new FileOutputStream(FilePath.MUL_IG_TEST_RESULT_PATH), "GBK"));
		String oneWeibo;

		/*
		 * ���ÿһƪ΢��
		 */
		for (int i = 0; i < trainPath.length; i++) {
			readEverySet = new BufferedReader(new InputStreamReader(
					new FileInputStream(trainPath[i][0]), "GBK"));
			while ((oneWeibo = readEverySet.readLine()) != null) {
				TrainSet set = new TrainSet(oneWeibo,trainPath[i][1]);
				allTrain.put(all, set);
				all++;
			}
		}
		
		countCHI(allTrain, all);
		ByValueComparator bvc = new ByValueComparator(feature);
		List<String> newList = new ArrayList<String>(feature.keySet());
		System.setProperty("java.util.Arrays.useLegacyMergeSort", "true");
		Collections.sort(newList, bvc);
		Iterator<String> it = newList.iterator();

		// ȡ30000ά
		for (int i = 0; i < FilePath.FEATURENUM; i++) {
			String str = it.next();
			result.write(str+"\r\n");
		}
		System.out.println("������Ϊ:"+FilePath.FEATURENUM+" ��");
		System.out.println(all + "ƪ΢��" + "\n" + "�ܹ�" + feature.size() + "������");
		result.close();
	}

	public static void main(String[] args) {
		long start = System.currentTimeMillis();
		try {
			coutCHI();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		long end = System.currentTimeMillis();
		System.out.println("time :" + (end - start) / 1000 + "s");
	}

	/*
	 * ��TreeMap��value��������
	 */
	static class ByValueComparator implements Comparator<String> {
		TreeMap<String, Double> base_map;

		public ByValueComparator(TreeMap<String, Double> base_map) {
			this.base_map = base_map;
		}

		// ��дcompare ����
		public int compare(String arg0, String arg1) {
			if (!base_map.containsKey(arg0) || !base_map.containsKey(arg1)) {
				return 0;
			}
			if (base_map.get(arg0) < base_map.get(arg1)) {
				return 1;
			} else if (base_map.get(arg0) == base_map.get(arg1)) {
				return 0;
			} else {
				return -1;
			}
		}
	}

	/*
	 * һƪ΢��һ����
	 */
	static class TrainSet {
		String kind;
		HashMap<String, Double> a = new HashMap<String, Double>();

		public TrainSet(String oneWeibo, String kind) {
			String s[];
			this.kind = kind;
			s = oneWeibo.split(" ");
			for (int i = 0; i < s.length; i++) {
				if (a.containsKey(s[i]))
					a.put(s[i], a.get(s[i]) + 1);
				else
					a.put(s[i], 1.0);
			}
            if(kind.equals("ANGRY")){
            	classes[0]++;
            }
            else if(kind.equals("FEAR")){
            	classes[1]++;
            }
            else if(kind.equals("GOOD")){
            	classes[2]++;
            }
            else if(kind.equals("HAPPY")){
            	classes[3]++;
            }
            else if(kind.equals("HATE")){
            	classes[4]++;
            }
            else if(kind.equals("MEAN")){
            	classes[5]++;
            }
            else if(kind.equals("SHOCK")){
            	classes[6]++;
            }
		}

		public String getKind() {
			return kind;
		}
	}

	static void countCHI(HashMap<Double, TrainSet> train, double n) {
		for (double i = 0; i < n; i++) {
			double CHI, countOneWord, tempCHI;

			// ���ÿ�����������Ŀ����0��3�ֱ�ΪANGRY, HAPPY,DOWN,DISGUST;
			double[] everyKind = {};
			Iterator<String> it = train.get(i).a.keySet().iterator();
			while (it.hasNext()) {
				String everyWord = it.next();
                everyKind =new double[]{0.0,0.0,0.0,0.0,0.0,0.0,0.0};
                countOneWord=0;
				CHI = countOneWord = 0;
				if (feature.containsKey(everyWord))
					continue;
				for (double j = 0; j < n; j++) {
					if (train.get(j).a.containsKey(everyWord)) {
                        if(train.get(j).getKind().equals("ANGRY")){
                        	everyKind[0]++;
                        }
                        else if(train.get(j).getKind().equals("FEAR")){
                        	everyKind[1]++;
                        }
                        else if(train.get(j).getKind().equals("GOOD")){
                        	everyKind[2]++;
                        }
                        else if(train.get(j).getKind().equals("HAPPY")){
                        	everyKind[3]++;
                        }
                        else if(train.get(j).getKind().equals("HATE")){
                        	everyKind[4]++;
                        }
                        else if(train.get(j).getKind().equals("MEAN")){
                        	everyKind[5]++;
                        }
                        else if(train.get(j).getKind().equals("SHOCK")){
                        	everyKind[6]++;
                        }
						countOneWord++;
					}
				}
				for (int k = 0; k < everyKind.length; k++) {
					tempCHI = Math
							.pow((everyKind[k]
									* (all - classes[k] - countOneWord + everyKind[k]) - (countOneWord - everyKind[k])
									* (classes[k] - everyKind[k])), 2)
							/ (countOneWord * (all - countOneWord));
					if (tempCHI >= CHI)
						CHI = tempCHI;
				}
				feature.put(everyWord, CHI);
			}
		}
	}

	public static String[][] getTrainPath() {
		return trainPath;
	}

	public static void setTrainPath(String[][] trainPath) {
		CHI.trainPath = trainPath;
	}

}
