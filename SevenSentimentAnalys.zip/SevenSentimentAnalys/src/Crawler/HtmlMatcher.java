package Crawler;

import java.util.*;
import java.util.regex.*;

/*
 * ƥ��htmlԴ��������
 */
public class HtmlMatcher {
	//�����û���ҳurl��ȡ�û�domain��url���û���������ҳ
	public static String getDomain(String content) {
		String domain = null;
		String regex1 = "<head>.*?</head>";
		String regex2 = "CONFIG\\['domain'\\]\\s?=\\s?'.*?'";
		Pattern pattern1 = Pattern.compile(regex1);
		Matcher matcher1 = pattern1.matcher(content);
		if (matcher1.find()) domain = matcher1.group();
		Pattern pattern2 = Pattern.compile(regex2);
		Matcher matcher2 = pattern2.matcher(domain);
		if (matcher2.find()) domain = matcher2.group();
		domain = domain.replaceFirst("^.*?=\\s?'", "").replaceFirst("'$", "");
		return domain;
	}
	
	//�����û���ҳurl��ȡ�û�page_id��url���û���������ҳ
	public static String getPage_id(String content) {
		String page_id = null;
//		String regex1 = "<head>.*?</head>";
		String regex1 = "<html>.*?</head>";
		String regex2 = "CONFIG\\['page_id'\\]\\s?=\\s?'.*?'";
		Pattern pattern1 = Pattern.compile(regex1);
		Matcher matcher1 = pattern1.matcher(content);
		if (matcher1.find()) page_id = matcher1.group();
		Pattern pattern2 = Pattern.compile(regex2);
		Matcher matcher2 = pattern2.matcher(page_id);
		if (matcher2.find()) page_id = matcher2.group();
		page_id = page_id.replaceFirst("^.*?=\\s?'", "").replaceFirst("'$", "");
		return page_id;
	}
	
	//�����û���ҳurl��ȡ�û�uid��url���û���������ҳ
	public static String getUID(String content) {
		String uid = null;
		String regex1 = "<head>.*?</head>";
		String regex2 = "CONFIG\\['oid'\\]\\s?=\\s?'.*?'";
		Pattern pattern1 = Pattern.compile(regex1);
		Matcher matcher1 = pattern1.matcher(content);
		if (matcher1.find()) uid = matcher1.group();
		Pattern pattern2 = Pattern.compile(regex2);
		Matcher matcher2 = pattern2.matcher(uid);
		if (matcher2.find()) uid = matcher2.group();
		uid = uid.replaceFirst("^.*?=\\s?'", "").replaceFirst("'$", "");
		return uid;
	}
	
	//ƥ����ҳ�е�ҳ����Ϣ�����򷵻�1
	public static int getPageNum(String html) {
		int pageNum = 1;
		Pattern pat = Pattern.compile("<div node-type=\\\\\"feed_list_page.*?<\\\\/a>");
		Matcher mat = pat.matcher(html);
		if (mat.find()) {
			String str = mat.group();
			str = str.replaceFirst("^.*?&nbsp;", "").replaceFirst("&nbsp;.*?$", "");
			pageNum = Integer.parseInt(str);
		}
		return pageNum;
	}
	
	//��һҳ΢���Ķ����������ݲ����һ����
	//html���Ĳ��ֲ���"<div node-type=\"lazyload"֮ǰ
	public static String insertHtml(String content, String content1, String content2) {
		String contentAdd = content1.replaceFirst("^.*?data\":\"","").replaceFirst("\"}$","")
				+content2.replaceFirst("^.*?data\":\"", "").replaceFirst("\"}$","");
		int insertPos = content.indexOf("<div node-type=\\\"lazyload");
		if (insertPos==-1) return content;
		String html = content.substring(0, insertPos)
				+contentAdd
				+content.substring(insertPos, content.length());
		html = html.replaceAll("<div node-type=\\\\\"lazyload.*?<\\\\/div>","");//ȥ��������
		return html;
	}
	
	//ƥ����ҳ�е�ȫ��΢��
	//tbinfoԭ����minfoת����node-type��ҳ��class=\"W_tips�����սᣬclass=\"W_main_2r���ս�
	public static List<Weibo> getPageWeibo(String html) {
		List<Weibo> pageWeibo = new ArrayList<Weibo>();
		Pattern pat = Pattern.compile("domid\":\"Pl_Official_LeftProfileFeed_"
				+ ".*?domid\":\"Pl_Official_LeftProfileFeedNav");
		Matcher mat = pat.matcher(html);
		String str = new String();
		//if (mat.find()) str = mat.group();
		str = html;
		int[] tbinfo = new int[107], minfo = new int[107];
		int tbnum = 0, mnum = 0;
		pat = Pattern.compile("<div\\s+minfo");
		mat = pat.matcher(str);
		while (mat.find()) minfo[mnum++] = mat.start();
		pat = Pattern.compile("<div\\s+tbinfo");
		mat = pat.matcher(str);
		while (mat.find()) tbinfo[tbnum++] = mat.start();
		for (int i=0; i<mnum; ++i) tbinfo[tbnum+i] = minfo[i];
		tbnum += mnum;
		for (int i=0; i<tbnum; ++i) for (int j=i+1; j<tbnum; ++j) {
			if (tbinfo[i] > tbinfo[j]) {int tmp=tbinfo[i];tbinfo[i]=tbinfo[j];tbinfo[j]=tmp;}
		}
		for (int i=0; i<tbnum-1; ++i) {
			Weibo weibo = getWeibo(str.substring(tbinfo[i], tbinfo[i+1]));
			if (weibo != null && weibo.valid()) pageWeibo.add(weibo);
		}
		if (tbnum > 0) {
			Weibo weibo = getWeibo(str.substring(tbinfo[tbnum-1], str.length()));
			if (weibo != null && weibo.valid()) pageWeibo.add(weibo);
		}
		return pageWeibo;
	}
	
	//��һ��΢����html����ƥ�������Ա
	public static Weibo getWeibo(String html) {
		String mid, uid, ruid, text, originText, weiboDate, source;
		int commentCount, repostCount, zanCount;
		mid="";uid="";ruid="";text="";originText="";weiboDate="";source="";
		commentCount=repostCount=zanCount=-1;
		Pattern pat, pat1;
		Matcher mat, mat1;
		
		//ԭ΢����ɾ����ת��΢��
		if(html.contains("<div class=\\\"WB_deltxt")) return null;
		
		if (html.contains("minfo")) {//ת��΢��
			pat = Pattern.compile("\\Wmid=\\d+\\D");
			mat = pat.matcher(html);
			if (mat.find()) mid = mat.group().replaceAll("^.*?=", "").replaceAll(".$", "");
			pat = Pattern.compile("\\Wouid=\\d+\\D");
			mat = pat.matcher(html);
			if (mat.find()) uid = mat.group().replaceAll("^.*?=", "").replaceAll(".$", "");
			pat = Pattern.compile("rouid=\\d+\\\\");
			mat = pat.matcher(html);
			if (mat.find()) ruid = mat.group().replaceAll("^.*?=","").replaceAll("\\\\$","");
			pat = Pattern.compile("<div\\s+class=\\\\\"WB_text.*?<\\\\/div>");
			mat = pat.matcher(html);
			if (mat.find()) {
				String textHtml = mat.group();
				pat = Pattern.compile("<img.*?>");
				mat = pat.matcher(textHtml);
				StringBuffer sb = new StringBuffer();
				while (mat.find()) {//�������
					String str = mat.group();
					pat1 = Pattern.compile("\\[.*?\\]");
					mat1 = pat1.matcher(str);
					if (mat1.find()) str = mat1.group();
					mat.appendReplacement(sb, str);
				}
				mat.appendTail(sb);
				text = sb.toString().replaceAll("<.*?>", "");
			}
			pat = Pattern.compile(
					"<div\\s+class=\\\\\"WB_media.*?<div\\s+class=\\\\\"WB_func");
			mat = pat.matcher(html);
			if (mat.find()) {
				String str = mat.group();
				pat = Pattern.compile("<div\\s+class=\\\\\"WB_text.*?<\\\\/div>");
				mat = pat.matcher(str);
				if (mat.find()) str = mat.group();
				originText = str.replaceAll("<.*?>","");
			}
			pat=Pattern.compile("<div\\s+class=\\\\\"WB_from.*?<\\\\/div>");
			mat = pat.matcher(html);
			if (mat.find()) {
				String str = mat.group();
				pat = Pattern.compile("\\d{4}-\\d+-\\d+\\s+\\d+:\\d+");
				mat = pat.matcher(str);
				if (mat.find()) weiboDate = mat.group();
			}
			pat = Pattern.compile("nofollow\\\\\">.*?<");
			mat = pat.matcher(html);
			if (mat.find()) source = mat.group().replaceAll("^.*?>","").replaceAll("<$","");
			pat = Pattern.compile("<div\\s+class=\\\\\"WB_handle\\\\\">.*?<\\\\/div>");
			mat = pat.matcher(html);
			if (mat.find()) {
				String str = mat.group();
				pat = Pattern.compile(
						"<em\\s+class=\\\\\"W_ico20\\s+icon_praised_b\\\\\"><\\\\/em>.*?<");
				mat = pat.matcher(str);
				if (mat.find()) {
					String zan = mat.group();
					if (zan.matches("^.*?\\(.*?$")) zanCount = Integer.parseInt(
							mat.group().replaceAll("^.*?\\(", "").replaceAll("\\).*?$", ""));
					else zanCount = 0;
				}
				pat = Pattern.compile("ת��.*?<");
				mat = pat.matcher(str);
				if (mat.find()) {
					String zhuanfa = mat.group();
					if (zhuanfa.matches("^.*?\\(.*?$")) repostCount = Integer.parseInt(
							zhuanfa.replaceAll("^.*?\\(", "").replaceAll("\\).*?$", ""));
					else repostCount = 0;
				}
				pat = Pattern.compile("����.*?<");
				mat = pat.matcher(str);
				if (mat.find()) {
					String pinglun = mat.group();
					if (pinglun.matches("^.*?\\(.*?$")) commentCount = Integer.parseInt(
							pinglun.replaceAll("^.*?\\(", "").replaceAll("\\).*?$", ""));
					else commentCount = 0;
				}
			}
		}
		else {//ԭ��΢��
			pat = Pattern.compile("\\Wmid=\\d+\\D");
			mat = pat.matcher(html);
			if (mat.find()) mid = mat.group().replaceAll("^.*?=", "").replaceAll(".$", "");
			pat = Pattern.compile("\\Wouid=\\d+\\D");
			mat = pat.matcher(html);
			if (mat.find()) uid = mat.group().replaceAll("^.*?=", "").replaceAll(".$", "");
			ruid = "11111111";
			pat = Pattern.compile("<div\\s+class=\\\\\"WB_text.*?<\\\\/div>");
			mat = pat.matcher(html);
			if (mat.find()) {
				String textHtml = mat.group();
				pat = Pattern.compile("<img.*?>");
				mat = pat.matcher(textHtml);
				StringBuffer sb = new StringBuffer();
				while (mat.find()) {//�������
					String str = mat.group();
					pat1 = Pattern.compile("\\[.*?\\]");
					mat1 = pat1.matcher(str);
					if (mat1.find()) str = mat1.group();
					mat.appendReplacement(sb, str);
				}
				mat.appendTail(sb);
				text = sb.toString().replaceAll("<.*?>", "");
			}
			originText = "";
			pat = Pattern.compile("<div\\s+class=\\\\\"WB_from.*?<\\\\/div>");
			mat = pat.matcher(html);
			if (mat.find()) {
				String str = mat.group();
				pat = Pattern.compile("\\d{4}-\\d+-\\d+\\s+\\d+:\\d+");
				mat = pat.matcher(str);
				if (mat.find()) weiboDate = mat.group();
			}
			pat = Pattern.compile("nofollow\\\\\">.*?<");
			mat = pat.matcher(html);
			if (mat.find()) source = mat.group().replaceAll("^.*?>","").replaceAll("<$","");
			pat = Pattern.compile("<div\\s+class=\\\\\"WB_handle.*?<\\\\/div>");
			mat = pat.matcher(html);
			if (mat.find()) {
				String str = mat.group();
				pat = Pattern.compile(
						"<em\\s+class=\\\\\"W_ico20\\s+icon_praised_b\\\\\"><\\\\/em>.*?<");
				mat = pat.matcher(str);
				if (mat.find()) {
					String zan = mat.group();
					if (zan.matches("^.*?\\(.*?$")) zanCount = Integer.parseInt(
							mat.group().replaceAll("^.*?\\(", "").replaceAll("\\).*?$", ""));
					else zanCount = 0;
				}
				pat = Pattern.compile("ת��.*?<");
				mat = pat.matcher(str);
				if (mat.find()) {
					String zhuanfa = mat.group();
					if (zhuanfa.matches("^.*?\\(.*?$")) repostCount = Integer.parseInt(
							zhuanfa.replaceAll("^.*?\\(", "").replaceAll("\\).*?$", ""));
					else repostCount = 0;
				}
				pat = Pattern.compile("����.*?<");
				mat = pat.matcher(str);
				if (mat.find()) {
					String pinglun = mat.group();
					if (pinglun.matches("^.*?\\(.*?$")) commentCount = Integer.parseInt(
							pinglun.replaceAll("^.*?\\(", "").replaceAll("\\).*?$", ""));
					else commentCount = 0;
				}
			}
		}
		return new Weibo(mid,uid,ruid,text,originText,weiboDate,
				commentCount,repostCount,zanCount,source);
	}
}
