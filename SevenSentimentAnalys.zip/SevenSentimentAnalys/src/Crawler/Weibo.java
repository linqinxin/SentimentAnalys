package Crawler;

import java.io.File;
import java.io.PrintWriter;
import java.util.*;

/*
 * ΢����
 */
public class Weibo {
	private String mid;//΢��mid
	private String uid;//�û�uid
	private String ruid;//ԭ����uid����ת��ʱ��Ϊ11111111
	private String text;//΢����
	private String originText;//ԭ΢���ģ���ת��ʱΪ��
	private Date weiboDate;//����
	private int commentCount;//������
	private int repostCount;//ת����
	private int zanCount;//����
	private String source;//��Դ
	
	public Weibo() {
	}
	
	public Weibo(String mid, String uid, String ruid, String text,
			String originText, String weiboDate, int commentCount,
			int repostCount, int zanCount, String source) {
		this.mid = mid;
		this.uid = uid;
		this.ruid = ruid;
		this.text = preProcessText(text);
		this.originText = preProcessText(originText);
		this.weiboDate = WeiboDate.String2Date(weiboDate);
		this.commentCount = commentCount;
		this.repostCount = repostCount;
		this.zanCount = zanCount;
		this.source = source;
	}
	
	public String getMid() {
		return mid;
	}
	public void setMid(String mid) {
		this.mid = mid;
	}
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String getRuid() {
		return ruid;
	}
	public void setRuid(String ruid) {
		this.ruid = ruid;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public String getOriginText() {
		return originText;
	}
	public void setOriginText(String originText) {
		this.originText = originText;
	}
	public Date getWeiboDate() {
		return weiboDate;
	}
	public void setWeiboDate(Date weiboDate) {
		this.weiboDate = weiboDate;
	}
	public void setWeiboDate(String weiboDate) {
		this.weiboDate = WeiboDate.String2Date(weiboDate);
	}
	public int getCommentCount() {
		return commentCount;
	}
	public void setCommentCount(int commentCount) {
		this.commentCount = commentCount;
	}
	public int getRepostCount() {
		return repostCount;
	}
	public void setRepostCount(int repostCount) {
		this.repostCount = repostCount;
	}
	public int getZanCount() {
		return zanCount;
	}
	public void setZanCount(int zanCount) {
		this.zanCount = zanCount;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	
	//Ԥ����text��originText��ȥ������ķ���
	private String preProcessText(String text) {
		return text.replaceAll("(\\\\n)|(\\\\t)","").replaceAll("\\\\/", "/")
				.trim().replaceAll("\\s+", " ");
	}
	
	//�ж�΢���Ƿ��Ӧ��Ա��������
	public boolean valid() {
		if (mid==null && mid.equals("")) return false;
		if (uid==null && uid.equals("")) return false;
		if (ruid==null && ruid.equals("")) return false;
		if (text==null && text.equals("")) return false;
		if (originText==null && originText.equals("")) return false;
		if (source==null && source.equals("")) return false;
		if (weiboDate==null) return false;
		if (commentCount==-1 || repostCount==-1 || zanCount==-1) return false;
		return true;
	}
	
	//�����Ա����
	public void print() {
		System.out.println("mid: " + mid);
		System.out.println("uid: " + uid);
		System.out.println("ruid: " + ruid);
		System.out.println("text: " + text);
		System.out.println("originText: " + originText);
		System.out.println("weiboDate: " + weiboDate);
		System.out.println("commentCount: " + commentCount);
		System.out.println("repostCount: " + repostCount);
		System.out.println("zanCount: " + zanCount);
		System.out.println("source: " + source);
	}
	
	//�����Ա����
	public void print(String path) {
		try {
			PrintWriter pw = new PrintWriter(new File(path), "UTF-8");
			pw.println("mid: " + mid);
			pw.println("uid: " + uid);
			pw.println("ruid: " + ruid);
			pw.println("text: " + text);
			pw.println("originText: " + originText);
			pw.println("weiboDate: " + weiboDate);
			pw.println("commentCount: " + commentCount);
			pw.println("repostCount: " + repostCount);
			pw.println("zanCount: " + zanCount);
			pw.println("source: " + source);
			pw.close();
		} catch (Exception ex) {}
	}
}
