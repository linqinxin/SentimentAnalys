package Crawler;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.*;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

/*
 * ����
 */
public class Crawler {
	private static String username = "gdufstest3@163.com";
	private static String password = "gdufsiiip";
	private static String uid = "2614841211";



	private static String charset = "UTF-8";
	private static String cookie;

	public static void main(String[] args) {
		setCookie(username, password);
		// RestrictTester.repeatAccess("uid");

		// ���û�uid��ȡ����΢��
		// Date date = WeiboDate.String2Date("2012-06-03 13:20");
		// ���������ھ���ȤС��
		// List<Weibo> weiboList = updateWeiboList(uid,date);

		// ���û�uid��ȡ����΢��
		List<Weibo> weiboList = crawlWeiboList(uid);

		ReadWrite.print(weiboList, "D:/gwsjwj.txt");

		// String html = crawlPage(uid, 4);
		// ReadWrite.print(html, "D:/test.htm");
		// List<Weibo> weiboList = readWeiboList("D:/test.htm");
		// ReadWrite.print(weiboList, "D:/weiboList.txt");

		// ����page_id
		// String html = ReadWrite.read("D:/first_page.htm");
		// String page_id = HtmlMatcher.getPage_id(html);
		// System.out.println("page_id = " + page_id);
	}

	// ����cookie
	public static void setCookie(String username, String password) {
		try {
			cookie = (new SinaWeiboAutoLogin()).getLoginCookie(username,
					password);
		} catch (Exception ex) {
		}
	}

	// ���û�uid��ȡ����΢��
	public static List<Weibo> crawlWeiboList(String uid) {
		String html = crawlLoginUrl("http://weibo.com/u/" + uid);
		String page_id = HtmlMatcher.getPage_id(html);// ÿ���û��̶�
		String domain = HtmlMatcher.getDomain(html);// ÿ���û��̶�
		List<Weibo> weiboList = new ArrayList<Weibo>();
		int pageNum = crawlPageNum(page_id, domain);
		for (int i = 1; i <= pageNum; ++i) {
			html = crawlPage(page_id, domain, i);
			List<Weibo> pageWeibo = HtmlMatcher.getPageWeibo(html);
			weiboList.addAll(pageWeibo);
			System.out.println("  page " + i + " get " + pageWeibo.size()
					+ " weibo");
		}
		System.out.println("get " + weiboList.size() + " weibo totally");
		return weiboList;
	}

	// ���û�uid��ȡ����΢��
	public static List<Weibo> updateWeiboList(String uid, Date date) {
		String html = crawlLoginUrl("http://weibo.com/u/" + uid);
		String page_id = HtmlMatcher.getPage_id(html);// ÿ���û��̶�
		String domain = HtmlMatcher.getDomain(html);// ÿ���û��̶�
		List<Weibo> weiboList = new ArrayList<Weibo>();
		int pageNum = crawlPageNum(page_id, domain);
		for (int i = 1; i <= pageNum; ++i) {
			html = crawlPage(page_id, domain, i);
			List<Weibo> pageWeibo = HtmlMatcher.getPageWeibo(html);
			List<Weibo> newWeibo = WeiboDate.getNewWeibo(pageWeibo, date);
			weiboList.addAll(newWeibo);
			System.out.println("  page " + i + " get " + newWeibo.size()
					+ " new weibo");
			// ��ȡ���ƶ�ʱ��֮ǰ��΢�����˳���ȡ�����ҳ��
			if (newWeibo.size() < pageWeibo.size())
				break;
		}
		System.out.println("get " + weiboList.size() + " new weibo totally");
		return weiboList;
	}

	// ��ȡ�ı����΢��
	public static List<Weibo> readWeiboList(String path) {
		String html = ReadWrite.read(path);
		return HtmlMatcher.getPageWeibo(html);
	}

	// �����û�΢����ҳurl�õ��û�΢��ҳ��
	public static int crawlPageNum(String page_id, String domain) {
		String html = crawlPage(page_id, domain, 1);
		int pageNum = HtmlMatcher.getPageNum(html);
		return pageNum;
	}

	// ��ȡһҳ������html����
	public static String crawlPage(String uid, int page) {// !!������
		String html = crawlLoginUrl("http://weibo.com/u/" + uid);
		String page_id = HtmlMatcher.getPage_id(html);// ÿ���û��̶�
		String domain = HtmlMatcher.getDomain(html);// ÿ���û��̶�
		String urlMain = "http://weibo.com/p/" + page_id + "/weibo?is_search=0"
				+ "&visible=0&is_tag=0&profile_ftype=1&page=" + page
				+ "#feedtop";
		String urlAdd1 = "http://weibo.com/p/aj/mblog/mbloglist?domain="
				+ domain + "&pre_page=" + page + "&page=" + page
				+ "&pagebar=0&id=" + page_id + "&feed_type=0";
		String urlAdd2 = "http://weibo.com/p/aj/mblog/mbloglist?domain="
				+ domain + "&pre_page=" + page + "&page=" + page
				+ "&pagebar=1&id=" + page_id + "&feed_type=0";
		String content = crawlLoginUrl(urlMain);
		String content1 = Decode.convertUTF8(crawlLoginUrl(urlAdd1));
		String content2 = Decode.convertUTF8(crawlLoginUrl(urlAdd2));
		return HtmlMatcher.insertHtml(content, content1, content2);
	}

	// ��ȡһҳ������html����
	public static String crawlPage(String page_id, String domain, int page) {
		String urlMain = "http://weibo.com/p/" + page_id + "/weibo?is_search=0"
				+ "&visible=0&is_tag=0&profile_ftype=1&page=" + page
				+ "#feedtop";
		String urlAdd1 = "http://weibo.com/p/aj/mblog/mbloglist?domain="
				+ domain + "&pre_page=" + page + "&page=" + page
				+ "&pagebar=0&id=" + page_id + "&feed_type=0";
		String urlAdd2 = "http://weibo.com/p/aj/mblog/mbloglist?domain="
				+ domain + "&pre_page=" + page + "&page=" + page
				+ "&pagebar=1&id=" + page_id + "&feed_type=0";
		String content = crawlLoginUrl(urlMain);
		String content1 = Decode.convertUTF8(crawlLoginUrl(urlAdd1));
		String content2 = Decode.convertUTF8(crawlLoginUrl(urlAdd2));
		return HtmlMatcher.insertHtml(content, content1, content2);
	}

	// ��ȡurl����ҳ���룬ʹ��ģ���½
	public static String crawlLoginUrl(String url) {
		StringBuilder sb = new StringBuilder();
		try {
			DefaultHttpClient client = new DefaultHttpClient();
			HttpGet httpGet = new HttpGet(url);
			httpGet.addHeader("Accept",
					"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
			httpGet.addHeader("Accept-Encoding", "deflate");
			httpGet.addHeader("Accept-Language",
					"zh-cn,zh;q=0.8,en-us;q=0.5,en;q=0.3");
			httpGet.addHeader("Connection", "	keep-alive");
			httpGet.addHeader("Cookie", cookie);
			// httpGet.addHeader("Host", "service.account.weibo.com");//Ĭ��
			httpGet.addHeader("Host", "weibo.com");// ��ͨ��
			// httpGet.addHeader("Host", "e.weibo.com");//��ҵ��
			// httpGet.addHeader("Host", "gov.weibo.com");//������
			httpGet.addHeader("User-Agent",
					"Mozilla/5.0 (Windows NT 6.2; WOW64; rv:20.0)"
							+ " Gecko/20100101 Firefox/20.0");
			HttpResponse response = client.execute(httpGet);
			HttpEntity entity = response.getEntity();
			BufferedReader br = new BufferedReader(new InputStreamReader(
					entity.getContent(), charset));
			String temp = null;
			while ((temp = br.readLine()) != null)
				sb.append(temp);// +"\n");
		} catch (Exception ex) {
		}
		return sb.toString();
	}

	// ��ȡurl����ҳ���룬��ʹ��ģ���½
	public static String crawlUrl(String url) {
		StringBuilder sb = new StringBuilder();
		try {
			DefaultHttpClient client = new DefaultHttpClient();
			HttpGet httpGet = new HttpGet(url);
			HttpResponse response = client.execute(httpGet);
			HttpEntity entity = response.getEntity();
			BufferedReader br = new BufferedReader(new InputStreamReader(
					entity.getContent(), charset));
			String line = null;
			while ((line = br.readLine()) != null)
				sb.append(line);
		} catch (Exception ex) {
		}
		return sb.toString();
	}

	//ͨ��cookie��ȡ�û���htmlҳ��Դ����
	public static String getUserWeiboSource() throws IOException {
		URL url = new URL("http://weibo.com");
		HttpURLConnection httpConnection = (HttpURLConnection) url.openConnection();
		httpConnection.setRequestProperty("User-Agent","Mozilla/4.0 (compatible; MSIE 6.0; Windows 2000)");
		httpConnection.setRequestProperty("Cookie",cookie);
		InputStream is = httpConnection.getInputStream();
		BufferedReader br = new BufferedReader(new InputStreamReader(is,"utf-8"));
		StringBuffer sb = new StringBuffer();
		while (br.readLine() != null) {
			sb.append(br.readLine() + "\n");
		}
		return sb.toString();
	}
	
	//ͨ��htmlҳ��Դ�����ȡ�û���uid
	public static String getUserWeiboUid() {
		String html="";
		try {
			html = getUserWeiboSource();
		} catch (IOException e) {
		}
		String uid = HtmlMatcher.getUID(html);
		System.out.println("uid: " + uid);
		return uid;
	}
	
}

/*
 * 
 * ����΢���û�����ѡ��ͬHost �����治��ƥ��uid����ҵ�������
 * 
 * ʶ������˵�Ƶ�����޲��ԣ�������ȡ�ȴ�ʱ�䣬ѹ������
 * 
 * ģ���½��ȡ��΢��ʱ�䲻�ܾ�ȷ����
 * 
 * �������ʽ����֮��ƥ���
 */
