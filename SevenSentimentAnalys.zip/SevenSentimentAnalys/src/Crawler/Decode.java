package Crawler;

import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/*
 * ����ҳԴ�����е�\u1234ת��Ϊ����
 */
public class Decode {
	public static String convertUTF8(String htmlCode) {
        String regex = "\\\\u[0-9A-Fa-f]{4}";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(htmlCode);
        StringBuffer sb = new StringBuffer();
        while (matcher.find()) {
            String str = matcher.group();
            matcher.appendReplacement(sb, string2UTF8(str));
        }
        matcher.appendTail(sb);
        return sb.toString();
    }
	
    private static String string2UTF8(String str) {
        int[] tmp = new int[4];
        for (int i=0;i<4;++i) {
            if (str.charAt(i+2)>='a') tmp[i] = 10 + str.charAt(i+2) - 'a';
            else if (str.charAt(i+2)>='A') tmp[i] = 10 + str.charAt(i+2) - 'A';
            else tmp[i] = str.charAt(i+2) - '0';
        }
        char[] c = new char[1];
        c[0] = (char)((((((tmp[0]*16)+tmp[1])*16)+tmp[2])*16)+tmp[3]);
        return Arrays.toString(c).substring(1,2);
    }
}
