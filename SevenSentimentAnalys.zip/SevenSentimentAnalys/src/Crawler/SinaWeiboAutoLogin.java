package Crawler;

import java.math.BigInteger;
import java.security.KeyFactory;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.RSAPublicKeySpec;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.crypto.Cipher;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.httpclient.cookie.CookiePolicy;
import org.apache.http.*;
import org.apache.http.client.*;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.*;
import org.apache.http.cookie.Cookie;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;

/*
 * ģ���½
 */
public class SinaWeiboAutoLogin {
	private String nonce;
	private String cookie = "";
	private long serverTime;
	private String pubkey;
	private String rsakv;
	private String sp;
	private String su;
	
	public String getLoginCookie(String username, String password) throws Exception {
		DefaultHttpClient client = new DefaultHttpClient();
		client.getParams().setParameter("http.protocol.cookie-policy", CookiePolicy.BROWSER_COMPATIBILITY);
		client.getParams().setParameter(HttpConnectionParams.CONNECTION_TIMEOUT, 5000);
		getParam(client);
		su = getEncodeUsername(username);
		sp = rsaEncrypt(pubkey, "10001", password, serverTime, nonce);
		String url = login(client);
		if(url.endsWith("-1"))
			System.out.println("��¼ʧ��");
		else{
			HttpGet httpGet = new HttpGet(url);
			client.execute(httpGet);
			for(Cookie c : client.getCookieStore().getCookies()){
				String s = c.toString();
				String name = s.substring(s.indexOf("name:")+5, s.indexOf("][value")).trim();
				String value = s.substring(s.indexOf("value:")+6, s.indexOf("][domain")).trim();
				cookie += name + "=" + value + ";";
			}
		}
		return cookie;
	}
	
	private void getParam(HttpClient httpClient) throws Exception{
		String prelogin = "http://login.sina.com.cn/sso/prelogin.php?"
				+"entry=weibo&callback=sinaSSOController.preloginCallBack&"+
				"su=&rsakt=mod&client=ssologin.js(v1.4.5)"
				+"&_=" +getCurrentTime(); 
		HttpGet httpGet = new HttpGet(prelogin);
		HttpResponse response = httpClient.execute(httpGet);
		String entity = EntityUtils.toString(response.getEntity());
		String targeStr = entity.substring(entity.indexOf("(") + 1, entity.indexOf(")"));
		JSONObject jso = new JSONObject(targeStr);
		serverTime = jso.getLong("servertime");
		nonce = jso.getString("nonce");
		pubkey = jso.getString("pubkey");
		rsakv = jso.getString("rsakv");
	}
	
	private String getEncodeUsername(String username){
		username.replace("@", "%40");
		return new String(Base64.encodeBase64(username.getBytes()));
	}
	
	private String rsaEncrypt(String modeHex, String exponentHex, 
			String password, long serverTime, String nonce) throws Exception {
		BigInteger  mode = new BigInteger(modeHex, 16);
		BigInteger  exponent = new BigInteger(exponentHex, 16);
		KeyFactory factory = KeyFactory.getInstance("RSA");
		RSAPublicKeySpec rspec = new RSAPublicKeySpec(mode, exponent);
		RSAPublicKey rkey = (RSAPublicKey)factory.generatePublic(rspec);
		Cipher enc = Cipher.getInstance("RSA");
		enc.init(Cipher.ENCRYPT_MODE, rkey);
		String newStr = serverTime + "\t" + nonce + "\n" + password;
		String ecodeStr = new String(Hex.encodeHex(enc.doFinal(newStr.getBytes("GB2312"))));
		return ecodeStr;
	}
	
	private String getCurrentTime() {
		return String.valueOf(new Date().getTime());
	}
	
	private String login(HttpClient client) throws Exception {
		HttpPost post = new HttpPost("http://login.sina.com.cn/sso/login.php?client=ssologin.js(v1.4.5)");
		List<NameValuePair> nvps = new ArrayList<NameValuePair>();
		nvps.add(new BasicNameValuePair("encoding", "UTF-8"));
		nvps.add(new BasicNameValuePair("entry", "weibo"));
		nvps.add(new BasicNameValuePair("from",""));
		nvps.add(new BasicNameValuePair("gateway", "1"));
		nvps.add(new BasicNameValuePair("nonce", nonce));
		nvps.add(new BasicNameValuePair("prelt", "66"));
		nvps.add(new BasicNameValuePair("pwencode", "rsa2"));
		nvps.add(new BasicNameValuePair("returntype", "META"));
		nvps.add(new BasicNameValuePair("rsakv", rsakv));
		nvps.add(new BasicNameValuePair("savestate", "7"));
		nvps.add(new BasicNameValuePair("servertime", serverTime + ""));
		nvps.add(new BasicNameValuePair("service", "miniblog"));
		nvps.add(new BasicNameValuePair("sp", sp));
		nvps.add(new BasicNameValuePair("su", su));
		nvps.add(new BasicNameValuePair("url", "http://weibo.com/ajaxlogin.php?"
				+ "framelogin=1&callback=parent.sinaSSOController.feedBackUrlCallBack"));
		nvps.add(new BasicNameValuePair("useticket", "1"));
		nvps.add(new BasicNameValuePair("vsnf", "1"));
		post.setEntity(new UrlEncodedFormEntity(nvps, HTTP.UTF_8));
		HttpResponse response = client.execute(post);
		String entity = EntityUtils.toString(response.getEntity());
		String url = "";
		try{
			url = entity.substring(entity.indexOf("http://weibo.com/sso/login.php?"), 
						entity.indexOf("retcode=0") + 9);
		}catch (Exception e) {
			url = "-1";
		}
		return url;
	}
}
