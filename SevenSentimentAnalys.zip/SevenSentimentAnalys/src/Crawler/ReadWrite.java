package Crawler;

import java.io.*;
import java.util.List;

/*
 * ��ȡ�ı����ݺ�д���ı�
 */
public class ReadWrite {
	private static String charset = "UTF-8";
	
	//���ַ��������һ���ı��в鿴����
	public static void print(String content, String path) {
		try {
			PrintWriter pw = new PrintWriter(new File(path), charset);
			pw.print(content);
			pw.close();
		} catch (Exception ex) {}
	}
	
	//���ַ��������һ���ı��в鿴����
	public static void print(String content) {
		String path = "D:/tmp.txt";
		try {
			PrintWriter pw = new PrintWriter(new File(path), charset);
			pw.print(content);
			pw.close();
		} catch (Exception ex) {}
	}
	
	//���ļ���ȡ����
	public static String read(String path) {
		StringBuilder str = new StringBuilder();
		try {
			BufferedReader reader = new BufferedReader(new FileReader(new File(path)));
			String line;
			while((line = reader.readLine()) != null) str.append(line);
			reader.close();
		} catch (Exception ex) {}
		return str.toString();
	}
	
	//���Weibo�������������
	public static void print(List<Weibo> list) {
		for (int i=0;i<list.size();++i) {
			list.get(i).print();
			System.out.println("\n");
		}
	}
	
	//���Weibo�������������
	public static void print(List<Weibo> list, String path) {
		try {
			PrintWriter pw = new PrintWriter(new File(path), "UTF-8");
			for (int i=0;i<list.size();++i) {
				pw.println("mid: " + list.get(i).getMid());
				pw.println("uid: " + list.get(i).getUid());
				pw.println("ruid: " + list.get(i).getRuid());
				pw.println("text: " + list.get(i).getText());
				pw.println("originText: " + list.get(i).getOriginText());
				pw.println("weiboDate: " + list.get(i).getWeiboDate());
				pw.println("commentCount: " + list.get(i).getCommentCount());
				pw.println("repostCount: " + list.get(i).getRepostCount());
				pw.println("zanCount: " + list.get(i).getZanCount());
				pw.println("source: " + list.get(i).getSource());
				pw.println("\n");
			}
			pw.close();
		} catch (Exception ex) {}
	}
}
