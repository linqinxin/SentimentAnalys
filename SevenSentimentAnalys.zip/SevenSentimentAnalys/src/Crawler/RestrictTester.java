package Crawler;

import java.util.*;

/*
 * ʶ������˵�Ƶ�ʲ���
 */
public class RestrictTester {
	//�ظ���ȡĳһҳ΢��
	public static void repeatAccess() {
        Date date = new Date();
        System.err.println("\n\n" + date);
		int num = 1;
		long sumtime = 0;
		while (true) {
			long time1 = System.currentTimeMillis();
			String html = Crawler.crawlLoginUrl("http://weibo.com/u/2671109275?is_search=0"
					+ "&visible=0&is_tag=0&profile_ftype=1&page=1#feedtop");
			List<Weibo> weiboList = HtmlMatcher.getPageWeibo(html);
			long time2 = System.currentTimeMillis();
			if (weiboList.size() == 0) {
		        date = new Date();
		        System.err.println(date);
				System.out.println("\n  !!  stop at NO." + num + "  store page to D:/error.htm");
				ReadWrite.print(html, "D:/error.htm");
				break;
			}
			System.out.println("page " + num + " get " + weiboList.size()
					+ " weibo\t\t " + (time2-time1)/1000.0 + "s");
			sumtime += time2 - time1;
			++num;
		}
		System.out.println("get " + num + "pages in total");
		System.out.println("average access time: " + sumtime/1000.0/num + "s");
	}
	
	//�ظ���ȡĳһҳ΢��
	public static void repeatAccess(String uid) {
		String html = Crawler.crawlLoginUrl("http://weibo.com/u/"+uid);
		String page_id = HtmlMatcher.getPage_id(html);//ÿ���û��̶�
		String domain = HtmlMatcher.getDomain(html);//ÿ���û��̶�
		int pageNum = Crawler.crawlPageNum(page_id, domain);
		System.out.println("uid:" + uid + " loop " + pageNum + "pages");
		int num = 1, errorNum = 0;
		long sumtime = 0;
		while (true) {
			long time1 = System.currentTimeMillis();
			html = Crawler.crawlPage(page_id, domain, num%pageNum+1);
			List<Weibo> weiboList = HtmlMatcher.getPageWeibo(html);
			long time2 = System.currentTimeMillis();
			if (weiboList.size() == 0) {
		        ++errorNum;
		        System.err.println(new Date() + "    !!  stop at NO." + num + 
						"  store page to D:/error" + errorNum + ".htm");
				ReadWrite.print(html, "D:/error" + errorNum + ".htm");
			}
			else {
				System.out.print(new Date() + "   No." + num + ": " + weiboList.size() 
						+ " weibo\t\t " + (time2-time1)/1000.0 + "s");
				sumtime += time2 - time1;
				System.out.println("  average: " + sumtime/1000.0/(num+errorNum) + "s");
				++num;
			}
		}
	}
}
