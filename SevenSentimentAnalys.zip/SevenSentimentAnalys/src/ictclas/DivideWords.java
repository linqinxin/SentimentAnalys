package ictclas;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;

import kevin.zhang.NLPIR;
import Utils.FilePath;

/*
 * �ִ�
 */
public class DivideWords {
	
    private NLPIR nlpir;
    private StringBuilder sb;
    private String divSource;
    private String divResult;
    
	public DivideWords() {
		nlpir = new NLPIR();
		sb = new StringBuilder();
		String argus=".";
		try {
			if(!(NLPIR.NLPIR_Init(argus.getBytes("GB2312"), 0))){
				System.out.println("Init Fail!");
				return;
			}
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}
	
	/*
	 * ���ͣ�ôʵ��ļ���
	 */
	public final HashMap<String, Boolean> getStopWords() throws IOException {
		BufferedReader reader = new BufferedReader(new InputStreamReader(
				new FileInputStream(new File(FilePath.STOPWORD_PATH)), "utf-8"));
		HashMap<String, Boolean> stopWords = new HashMap<String, Boolean>();
		String word;
		while ((word = reader.readLine()) != null) {
			stopWords.put(word, true);
		}
		reader.close();
		return stopWords;
	}
	
    /*
     * �Ƴ�ͣ�ô��ļ��еķ񶨴�
     */
	public final void removeDenyWordsInStopWords(HashMap<String, Boolean> stopWords) throws IOException{
		BufferedReader reader = new BufferedReader(new FileReader(new File(FilePath.DENYWORD_PATH)));
		String word;
		while((word = reader.readLine()) != null){
			stopWords.remove(word);
		}
		reader.close();
	}

	/*
	 *�Էֺôʵ��ļ������Ƿ񱣴�񶨴ʣ��Լ�ȥ��ͣ�ôʡ� 
	 */
	public final void deleteStopWords(boolean saveDenyWords) throws IOException {
		File orignalFile = new File(FilePath.ORIGNAL_RESULT_PATH);
		BufferedReader reader = new BufferedReader(new FileReader(orignalFile));
		BufferedWriter writer = new BufferedWriter(new FileWriter(new File(
				divResult)));
		HashMap<String, Boolean> stopWords = getStopWords();
		String string;
		String[] strings;
		StringBuilder stringBuilder = new StringBuilder();
		if(saveDenyWords){
			removeDenyWordsInStopWords(stopWords);
		}
		
		while ((string = reader.readLine()) != null) {
			if (!string.equals(" ")) {
				strings = string.split(" ");
				stringBuilder.delete(0, stringBuilder.length());
				for (String word : strings) {
					if (!stopWords.containsKey(word)) {
						stringBuilder.append(word + " ");
					}
				}

				writer.write(stringBuilder.toString() + "\r\n");
			}
		}
		reader.close();
		writer.flush();
		writer.close();
		orignalFile.delete();
	}

	/*
	 * ��ȡ����Դ�ļ���
	 */
	public final void divideWordsInFile() throws IOException {
		BufferedReader reader = new BufferedReader(new FileReader(new File(
				divSource)));
		BufferedWriter writer = new BufferedWriter(new FileWriter(new File(
				FilePath.ORIGNAL_RESULT_PATH)));
		String string;
		while ((string = reader.readLine()) != null) {
			string = dissect(string)+"\n";
			writer.write(string);
		}
		reader.close();
		writer.flush();
		writer.close();
	}

	public final void divideWords(String divSource,String divResult) throws IOException {
		this.divSource=divSource;
		this.divResult=divResult;
		divideWordsInFile();
		deleteStopWords(false);
	}

	/*
	 * ÿһ�е���һ�ηִʡ�
	 */
	public String dissect(String input) {
		try {
			// �����û��ʵ�ǰ
			sb.delete(0, sb.length());
			byte nativeBytes[] = nlpir.NLPIR_ParagraphProcess(input.getBytes("GB2312"), 0);
			sb = new StringBuilder( new String(nativeBytes, 0, nativeBytes.length,"GB2312"));
	           if (sb.length() > 0) {
	               sb.setLength(sb.length() - 1);
	            }
			return sb.toString();
		} catch (Exception e) {
			e.printStackTrace();
			return "error";
		}
	}

	public static void main(String[] args) {
		DivideWords divideWords = new DivideWords();
		try {
			for(int i=0;i<FilePath.MUL_DIV_SRC_PATH.length;i++){
				long start = System.currentTimeMillis();
			    divideWords.divideWords(FilePath.MUL_DIV_SRC_PATH[i],FilePath.MUL_DIV_RESULT_PATH[i][0]);
			    long end = System.currentTimeMillis();
			    System.out.println("��"+(i+1)+" �ηִʳɹ� ! \t\t" + "time : " + (end - start) / 1000+ "s");
			}
		} catch (IOException e) {
		}
		NLPIR.NLPIR_Exit();
	}
}
