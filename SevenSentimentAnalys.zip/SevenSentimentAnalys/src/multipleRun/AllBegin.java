package multipleRun;

import ictclas.DivideWords;

import java.io.IOException;

import liblinear.InvalidInputDataException;
import liblinear.Predict;
import liblinear.Train;
import selectFeature.IG;
import Utils.FilePath;
import countTFIDF.MUILT_TFIDF;

public class AllBegin {
	
	public static void run() throws IOException,
	InvalidInputDataException{
		System.out.println("�ִʿ�ʼ��");
		DivideWords.main(null);
		System.out.println("������ȡ��ʼ��");
		IG.main(null);
		System.out.println("ѵ����������ֵ���㿪ʼ��");
		
		MUILT_TFIDF.setPath(FilePath.MUL_DIV_RESULT_PATH,FilePath.SVM_IG_FILE_PATH ,FilePath.MUL_IG_TEST_RESULT_PATH);
//		MUILT_TFIDF.main(null);
		System.out.println("���Լ�������ֵ���㿪ʼ��");
		MUILT_TFIDF.setPath(FilePath.MUL_DIV_RESULT_PATH,FilePath.SVM_IG_FILE_QUIZ_PATH ,FilePath.MUL_IG_TEST_RESULT_PATH);
//		MUILT_TFIDF.main(null);
		System.out.println("SVMѵ����ʼ��");
		Train.main(null);
		System.out.println("SVMԤ�⿪ʼ��");
		Predict.main(null);
	}
	
	public static void main(String[] args) throws IOException,
			InvalidInputDataException {
		long begin = System.currentTimeMillis();
		run();
		long end = System.currentTimeMillis();
		System.out.println("\nTotal time�� " +  (end - begin)
				/ 60000+ "min "+(end-begin)/1000%60+" s");	
	}

}
