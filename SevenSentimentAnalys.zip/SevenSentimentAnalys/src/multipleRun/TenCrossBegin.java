package multipleRun;

import java.io.IOException;

import liblinear.InvalidInputDataException;
import liblinear.Predict;
import liblinear.Train;
import selectFeature.IG;
import Utils.FilePath;
import Utils.ReaderFileLine;
import countTFIDF.MUILT_TFIDF;

public class TenCrossBegin {
    private static ReaderFileLine readFile ;
    
    public  static void begin(int i) throws IOException, InvalidInputDataException{
    	for(int num=0;num<FilePath.MUL_DIV_RESULT_PATH.length;num++){
		    readFile = new ReaderFileLine(FilePath.MUL_DIV_RESULT_PATH[num][0],FilePath.TEN_CROSS_TRAIN_PATH[num][0]);
		    if(i!=9){
		        readFile.readLineToLine(0, (9-i)*50);
		    }
		    if(i!=0){
		    	if(i==9){
		    		readFile.readLineToLine((9-i+1)*50,500);
		    	}
		    	else{
		    		readFile.appendLineToLine((9-i+1)*50,500);
		    	}
		    }
		}
		for(int num=0;num<FilePath.MUL_DIV_RESULT_PATH.length;num++){
		    readFile = new ReaderFileLine(FilePath.MUL_DIV_RESULT_PATH[num][0],FilePath.TEN_CROSS_TEST_PATH[num][0]);
		    readFile.readLineToLine((9-i)*(50), (10-i)*(50));
		}
		System.out.println("������ȡ��ʼ��");
		IG.setTrainPath(FilePath.TEN_CROSS_TRAIN_PATH);
		IG.main(null);
		
		System.out.println("ѵ����������ֵ���㿪ʼ��");
		MUILT_TFIDF.setPath(FilePath.TEN_CROSS_TRAIN_PATH,FilePath.SVM_IG_FILE_PATH,FilePath.MUL_IG_TEST_RESULT_PATH);
		MUILT_TFIDF.main(null);
		
		System.out.println("���Լ�������ֵ���㿪ʼ��");
		MUILT_TFIDF.setPath(FilePath.TEN_CROSS_TEST_PATH,FilePath.SVM_IG_FILE_QUIZ_PATH,FilePath.MUL_IG_TEST_RESULT_PATH);
		MUILT_TFIDF.main(null);
		
		System.out.println("SVMѵ����ʼ��");
		Train.main(null);
		System.out.println("SVMԤ�⿪ʼ��");
		Predict.main(null);
    }
    
    public static void run() throws IOException,InvalidInputDataException {
        //System.out.println("�ִʿ�ʼ��");
        //DivideWords.main(null);
		for (int i = 0; i < 10; i++) {
			System.out.println("10�۽�����֤��"+(i+1)+"�ο�ʼ");
			begin(i);
		}
    }
    
	public static void main(String[] args) throws IOException,InvalidInputDataException {
		long begin = System.currentTimeMillis();
		run();
		long end = System.currentTimeMillis();
		System.out.print("10�۽�����֤ƽ��׼ȷ��Ϊ ");
		System.out.print(FilePath.ACCURACY*100/10);
		System.out.println("%");
		System.out.println("\nTotal time�� " + (end - begin)/ 60000.0 + "min"+(end-begin)/1000%60+" s");
	}

}
