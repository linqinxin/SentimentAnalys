package �Ҷ��ִ�;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.util.HashMap;

import net.paoding.analysis.analyzer.PaodingAnalyzer;

import org.apache.lucene.analysis.Token;
import org.apache.lucene.analysis.TokenStream;

import Utils.FilePath;



public class DivideWords {
	private PaodingAnalyzer analyzer;	 
    private StringBuilder sb;
 
    public DivideWords( ){
    	analyzer = new PaodingAnalyzer();
    	sb = new StringBuilder();
    }
    
    /*
     * ���ͣ�ôʵ��ļ���
     */
    public final HashMap<String, Boolean> getStopWords( ) throws IOException{
		BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(new File(FilePath.STOPWORD_PATH)),"utf-8"));
		HashMap<String, Boolean> stopWords = new HashMap<String, Boolean>();
		String word;
		while((word = reader.readLine()) != null){
			stopWords.put(word, true);
		}
		reader.close();
		return stopWords;
	}
    /*
     * �Ƴ�ͣ�ô��ļ��еķ񶨴�
     */
	public final void removeDenyWordsInStopWords(HashMap<String, Boolean> stopWords) throws IOException{
		BufferedReader reader = new BufferedReader(new FileReader(new File(FilePath.DENYWORD_PATH)));
		String word;
		while((word = reader.readLine()) != null){
			stopWords.remove(word);
		}
		reader.close();
	}

	/*
	 * �Էֺôʵ��ļ������Ƿ񱣴�񶨴ʣ��Լ�ȥ��ͣ�ôʡ� 
	 */
	public final void deleteStopWords(boolean saveDenyWords) throws IOException{
		File orignalFile = new File(FilePath.ORIGNAL_RESULT_PATH);
		BufferedReader reader = new BufferedReader(new FileReader(orignalFile));
		BufferedWriter writer = new BufferedWriter(new FileWriter(new File("")));
		HashMap<String, Boolean> stopWords = getStopWords();
		if(saveDenyWords){
			removeDenyWordsInStopWords(stopWords);
		}
		String string;
		String [] strings;
		StringBuilder stringBuilder = new StringBuilder();
		
		while ((string = reader.readLine()) != null) {
			if(!string.equals(" ")){
				strings = string.split(" ");
				stringBuilder.delete(0, stringBuilder.length());
				for(String word : strings){
					if(!stopWords.containsKey(word)){
						stringBuilder.append(word + " ");
					}
				}
			
				writer.write(stringBuilder.toString() + "\r\n");
			}				
		}
		reader.close();
		writer.flush();
		writer.close();
		orignalFile.delete();
	}
	
	/*
	 * ��ȡ����Դ�ļ���
	 */
	public final void divideWordsInFile( ) throws IOException{
		BufferedReader reader = new BufferedReader(new FileReader(new File("")));
		BufferedWriter writer = new BufferedWriter(new FileWriter(new File(FilePath.ORIGNAL_RESULT_PATH)));
		String string;
		while((string = reader.readLine()) != null){
			string = dissect(string);
			writer.write(string + "\r\n");
		}
		reader.close();
		writer.flush();
		writer.close();
	}
	
	public final void divideWords( ) throws IOException{
		divideWordsInFile( );
		deleteStopWords(false);
	}
	
	/*
	 * ÿһ�е���һ�ηִʡ�
	 */
    public String dissect(String input) {
       try {
           TokenStream ts = analyzer.tokenStream("", new StringReader(input));
           Token token;
           sb.delete(0, sb.length());
           while ((token = ts.next()) != null) {
              sb.append(token.termText()).append(" ");
           }
           if (sb.length() > 0) {
              sb.setLength(sb.length() - 1);
           }
           return sb.toString();
       } catch (Exception e) {
           e.printStackTrace();
           return "error";
       }
    }
    
    public static void main(String[] args){
    	long start = System.currentTimeMillis();
    	DivideWords divideWords = new DivideWords();
    	try {
			divideWords.divideWords();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	long end = System.currentTimeMillis();
    	System.out.println("success ! \r\n" + "time : " + (end - start) / 1000 + "s" );
    }
}
