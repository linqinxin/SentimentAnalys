package countTFIDF;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;

public class MUILT_TFIDF {
	private int wordsNum;
	private int[] weiboNum;
	private int kindNum;
	private ArrayList<String> words;
	private HashMap<String, Integer> allWordsDF;
	private ArrayList<HashMap<String, Integer>> allWeiBo;
	private ArrayList<String> result;

	// ����ֵ����Դ·��
	private static String[][] SRC_PATH;
	//����ֵ������
	private static String RESULT_PATH;
	//������·��
	private static String FEATURE_PATH;
	
	private final void readWords() throws IOException {
		BufferedReader reader = new BufferedReader(new FileReader(new File(
				FEATURE_PATH)));
		String word;
		while ((word = reader.readLine()) != null) {
			words.add(word);
			wordsNum++;
		}
		reader.close();
	}

	private final void putData(String lineString) {
		int i;
		String string;
		String[] arrays = lineString.split(" ");
		int size = arrays.length;
		HashMap<String, Integer> hashMap = new HashMap<String, Integer>(
				size * 2);
		HashMap<String, Integer> hashMap0 = new HashMap<String, Integer>(
				size * 2);
		for (i = 0; i < size; i++) {
			string = arrays[i];
			if (!hashMap0.containsKey(string)) {

				if (allWordsDF.containsKey(string)) {
					allWordsDF.put(string, allWordsDF.get(string) + 1);
				} else {
					allWordsDF.put(string, 1);
				}
				hashMap0.put(string, 1);

			}

			if (hashMap.containsKey(string)) {
				hashMap.put(string, hashMap.get(string) + 1);
			} else {
				hashMap.put(string, 1);
			}
		}
		allWeiBo.add(hashMap);
	}

	private final void readData() throws IOException {

		BufferedReader reader = null;
		String lineString;
		for (int i = 0; i < kindNum; i++) {
			reader = new BufferedReader(new InputStreamReader(
					new FileInputStream(SRC_PATH[i][0]),
					"GBK"));
			while ((lineString = reader.readLine()) != null) {
				putData(lineString);
				weiboNum[i]++;
			}
		}
		reader.close();
	}

	private final double coutAWordTF(String word, HashMap<String, Integer> weiBo) {
		double tf = (double) (weiBo.get(word)) / (double) (weiBo.size());
		double df = (double) (allWeiBo.size())
				/ (double) (allWordsDF.get(word));
		return (1 + Math.log10(tf)) * Math.log10(df);
	}

	private final void coutOneWeiBoWeight(int index) {
		HashMap<String, Integer> weiBo = allWeiBo.get(index);
		StringBuilder resultBuilder = new StringBuilder(wordsNum + 1);
		String word;

		int sum = 0;
		for (int i = 0; i < kindNum; i++) {// ���ݶ���ʱ��˳�����ж�΢�����
			if (index < weiboNum[i] + sum) {
				resultBuilder.append(i + " ");
				break;
			}
			sum += weiboNum[i];
		}

		double tfidf;
		for (int i = 0; i < wordsNum; i++) {
			word = words.get(i);
			if (weiBo.containsKey(word)) {
				tfidf = coutAWordTF(word, weiBo);
				resultBuilder.append((i + 1) + ":" + tfidf + " ");
			} else {
				resultBuilder.append((i + 1) + ":0.0 ");
			}
		}

		result.add(resultBuilder.toString());
	}

	private final void coutTF() {
		int i;
		int size = allWeiBo.size();
		for (i = 0; i < size; i++) {
			coutOneWeiBoWeight(i);
		}
	}

	private final void writeData() throws IOException {
		BufferedWriter writer = new BufferedWriter(new FileWriter(new File(
				RESULT_PATH)));
		for (String line : result) {
			writer.write(line + "\r\n");
		}
		writer.close();
	}

	private final void start() throws IOException {
		long start = System.currentTimeMillis();
		init();
		readWords();// ��ȡ������
		readData();
		coutTF();
		writeData();
		long end = System.currentTimeMillis();
		System.out.print("�����ʣ�" + wordsNum + "\t");
		for (int i = 0; i < kindNum; i++) {
			System.out.print(SRC_PATH[i][1] + ": " + weiboNum[i]
					+ "ƪ\t");
		}

		System.out.println("time : " + (end - start) / 1000 + "s");
	}

	private final void init() {
		wordsNum = 0;
		kindNum = 7;
		weiboNum = new int[kindNum];
		words = new ArrayList<String>();
		allWordsDF = new HashMap<String, Integer>();
		allWeiBo = new ArrayList<HashMap<String, Integer>>();
		result = new ArrayList<String>();
	}

	public static void main(String[] arg) {
		MUILT_TFIDF tfidf = new MUILT_TFIDF();
		try {
			tfidf.start();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static String[][] getSRC_PATH() {
		return SRC_PATH;
	}

	public static void setSRC_PATH(String[][] sRC_PATH) {
		SRC_PATH = sRC_PATH;
	}

	public static String getRESULT_PATH() {
		return RESULT_PATH;
	}

	public static void setRESULT_PATH(String rESULT_PATH) {
		RESULT_PATH = rESULT_PATH;
	}

	public static String getFEATURE_PATH() {
		return FEATURE_PATH;
	}

	public static void setFEATURE_PATH(String fEATURE_PATH) {
		FEATURE_PATH = fEATURE_PATH;
	}
	
	public static void setPath(String[][] sRC_PATH,String rESULT_PATH,String fEATURE_PATH) {
		RESULT_PATH = rESULT_PATH;
		SRC_PATH = sRC_PATH;
		FEATURE_PATH = fEATURE_PATH;
	}
}
