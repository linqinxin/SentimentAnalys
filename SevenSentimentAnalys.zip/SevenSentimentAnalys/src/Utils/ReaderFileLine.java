package Utils;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;

public class ReaderFileLine {
	private static List<String> fileList;
	private static String targetPath;
	private static BufferedReader readFile;
	private static BufferedWriter writeFile;
	private static BufferedWriter writeAppendFile;
	/*
	 * construct function.
	 * by giving the file path and target path.
	 */
	public ReaderFileLine(String srcPath,String targetPath){
		try {
			ReaderFileLine.targetPath = targetPath;
			fileList = new ArrayList<String>();
			readFile = new BufferedReader(new FileReader(new File(srcPath)));
			String str="";
			while((str=readFile.readLine())!=null){
		        fileList.add(str);
		    }
			readFile.close();
		}
		 catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	//get the file context from startLine to endLine by writing them to the file of targetPath.
	public  void readLineToLine(int startLine,int endLine){
		try {
			writeFile = new BufferedWriter(new FileWriter(new File(targetPath)));
			if(fileList.size()>=(endLine-1)){
				for(int i=startLine;i<endLine;i++){
					writeFile.write(fileList.get(i)+"\r\n");
				}
				writeFile.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}	
	
	public  void appendLineToLine(int startLine,int endLine){
		try {
			writeAppendFile = new BufferedWriter(new OutputStreamWriter(                        
                    new FileOutputStream(targetPath, true)));   
			if(fileList.size()>=(endLine-1)){
				for(int i=startLine;i<endLine;i++){
					writeAppendFile.write(fileList.get(i)+"\r\n");
				}
				writeAppendFile.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}	
	
	//get the specified line of the file context.
	public  String readOneLine(int line){
		String tempStr="";
		if(fileList.size()>=(line-1)){
			tempStr=fileList.get(line);
		}
		return tempStr;
	}
	
	public static void main(String[] args){
		ReaderFileLine read = new ReaderFileLine("./File/multielement/tenCross/trainSet/sample_0.txt","./File/multielement/tenCross/sample_0.txt");
		System.out.println(read.readOneLine(10));
	}
	
}
