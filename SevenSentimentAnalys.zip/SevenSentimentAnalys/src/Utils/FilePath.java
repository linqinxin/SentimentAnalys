package Utils;


public class FilePath {

	
	public static final String ORIGNAL_RESULT_PATH = "./File/resultWithStopWords.txt";//�ִ�Դ�ļ�����ͣ�ô�
	public static final String STOPWORD_PATH = "./File/stopwords.txt";//ͣ�ô��ļ�
	public static final String DENYWORD_PATH = "./File/denyWords.txt";//�񶨴��ļ�
	
	public static final String USER_DIC_PATH="E:/ѧϰ����/eclipse_cn/workspace/SentimentAnalys/userDic/";//�û��ʵ�Ŀ¼
	
	//��Ԫ����   SVM
	public static final String SVM_IG_FILE_PATH = "./File/SVM/IG/trainFeature.txt";//svmѵ����
	public static final String SVM_IG_MODEL_PATH = "./File/SVM/IG/model.txt";//svm model�ļ�
	public static final String SVM_IG_RESULT_PAHT = "./File/SVM/IG/result.txt";//svmԤ����
	public static final String SVM_IG_FILE_QUIZ_PATH = "./File/SVM/IG/testFeature.txt";//svm���Լ�
	
	
	//��Ԫ����7��Դ�ļ� ���ֱ��ǣ� ��ŭ �־� ϲ�� ���� ��� mean ����
	public static final String[]  MUL_DIV_SRC_PATH=new String[]
		{"./File/multielement/divSource/anger.txt",
		"./File/multielement/divSource/fear.txt",
		"./File/multielement/divSource/good.txt",	
		"./File/multielement/divSource/happy.txt",
		"./File/multielement/divSource/hate.txt",
		"./File/multielement/divSource/mean.txt",
		"./File/multielement/divSource/shock.txt"};	 
	
	
	//��Ԫ���ྭ���ִʵ�7������ ���ֱ��ǣ� ��ŭ �־� ϲ�� ���� ��� mean ����
	public static final String[][] MUL_DIV_RESULT_PATH=new String[][]
			{{"./File/multielement/source/all/anger.txt","ANGRY"},
		{"./File/multielement/source/all/fear.txt","FEAR"},
		{"./File/multielement/source/all/good.txt","GOOD"},
		{"./File/multielement/source/all/happy.txt","HAPPY"},
		{"./File/multielement/source/all/hate.txt","HATE"},
		{"./File/multielement/source/all/mean.txt","MEAN"},
		{"./File/multielement/source/all/shock.txt","SHOCK"},
		};	
	
	
	//��Ԫ��������ѡ���� 
	public static final String MUL_IG_RESULT_PATH="./File/multielement/featureResult/all/mul_ig_result.txt";



	//���ļ��Ƚ�С�ģ���Ԫ��������ѡ���� (ѵ��������)
	public static final String MUL_IG_TEST_RESULT_PATH="./File/multielement/featureResult/mul_ig_result.txt";

	//׼ȷ��                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         
	public static double ACCURACY=0.0;
	
	//��������Ŀ
	public static final int FEATURENUM=3000;
	
	
	//10�۽�����֤ѵ���������Լ�·����DF��IG��MI�� CHI 
	public static final String[][] TEN_CROSS_TRAIN_PATH=new String[][]
			{{"./File/multielement/tenCross/trainSet/anger.txt","ANGRY"},
		{"./File/multielement/tenCross/trainSet/fear.txt","FEAR"},
		{"./File/multielement/tenCross/trainSet/good.txt","GOOD"},
		{"./File/multielement/tenCross/trainSet/happy.txt","HAPPY"},
		{"./File/multielement/tenCross/trainSet/hate.txt","HATE"},
		{"./File/multielement/tenCross/trainSet/mean.txt","MEAN"},
		{"./File/multielement/tenCross/trainSet/shock.txt","SHOCK"}};	
	
	public static final String[][] TEN_CROSS_TEST_PATH=new String[][]
			{{"./File/multielement/tenCross/testSet/anger.txt","ANGRY"},
		{"./File/multielement/tenCross/testSet/fear.txt","FEAR"},
		{"./File/multielement/tenCross/testSet/good.txt","GOOD"},
		{"./File/multielement/tenCross/testSet/happy.txt","HAPPY"},
		{"./File/multielement/tenCross/testSet/hate.txt","HATE"},
		{"./File/multielement/tenCross/testSet/mean.txt","MEAN"},
		{"./File/multielement/tenCross/testSet/shock.txt","SHOCK"}};	
}